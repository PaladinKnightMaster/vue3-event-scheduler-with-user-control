<template>
    <div class="p-4">
        <div class="container">
            <router-view />
        </div>
    </div>
</template>

