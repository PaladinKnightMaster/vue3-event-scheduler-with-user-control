<script setup>
import { storeToRefs } from 'pinia';
import { useAuthStore } from '@/stores';
import { Qalendar } from "qalendar";

import { Form, Field } from 'vee-validate';
import * as Yup from 'yup';

const authStore = useAuthStore();
const { user } = storeToRefs(authStore);

const schema = Yup.object().shape({
  name: Yup.string()
    .required('Username is required'),
  email: Yup.string()
    .matches(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/, 'Email is not valid')
    .required('Email is required'),
  phone: Yup.string()
    .matches(/^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/, "Phone number is not valid")
    .required('Last Name is required'),
  is_admin: Yup.number()
    .required('Role is required'),
  password: Yup.string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters')
});

const events = [
  {
    title: "Break",
    with: "Marshall Eriksen",
    time: { start: "2023-01-12 22:10", end: "2023-01-12 22:55" },
    colorScheme: "meetings",
    isEditable: true,
    id: "9f1b209982f1",
    location: "Zoom",
  },
  {
    title: "Meeting with Dora",
    with: "Albert Einstein",
    time: { start: "2023-01-10", end: "2023-01-11" },
    color: "green",
    isEditable: true,
    id: "de471c78cb5c",
    description:
      "Think of me as Yoda. Only instead of being little and green, I wear suites and I'm awesome.",
  },
];
const config = {
  defaultMode: "month",
  style: {
    colorSchemes: {
      meetings: {
        color: "#fff",
        backgroundColor: "#ff4081",
      },
      sports: {
        color: "#fff",
        backgroundColor: "#131313",
      },
    },
  },
};

</script>

<template>
    <div v-if="user">
        <dialog v-if="isFormShow">
          <Form @submit="onSubmit" :validation-schema="schema" v-slot="{ errors, isSubmitting }">
            <div class="form-group">
              <label>Username</label>
              <Field name="name" type="text" class="form-control" :class="{ 'is-invalid': errors.name }" />
              <div class="invalid-feedback">{{ errors.name }}</div>
            </div>
            <div class="form-group">
                <label>Email</label>
                <Field name="email" type="text" class="form-control" :class="{ 'is-invalid': errors.email }" />
                <div class="invalid-feedback">{{ errors.email }}</div>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <Field name="phone" type="text" class="form-control" :class="{ 'is-invalid': errors.phone }" />
                <div class="invalid-feedback">{{ errors.phone }}</div>
            </div>
            <div class="form-group">
              <label>User Role</label>
              <Field name="is_admin" as="select" class="form-control" :class="{ 'is-invalid': errors.is_admin }">
                <option value="" disabled>Select a User Role</option>
                <option v-for="role in user_roles" :key="role.value" :value="role.value">{{ role.text }}</option>
              </Field>
              <div class="invalid-feedback">{{ errors.is_admin }}</div>
            </div>
            <div class="form-group">
              <label>Password</label>
              <Field name="password" type="password" class="form-control" :class="{ 'is-invalid': errors.password }" />
              <div class="invalid-feedback">{{ errors.password }}</div>
            </div>
            <div class="form-group">
              <button class="btn btn-primary" :disabled="isSubmitting">
                  <span v-show="isSubmitting" class="spinner-border spinner-border-sm mr-1"></span>
                  Register
              </button>
              <router-link to="login" class="btn btn-link">Cancel</router-link>
            </div>
          </Form>
        </dialog>
        <!-- <p><router-link to="/users">Manage Users</router-link></p> -->
        <!-- <Qalendar
          :selected-date="new Date()"
          :events="events"
          :config="config"
          @event-was-clicked="reactToEvent"
          @updated-period="updatedPeriod"
          @updated-mode="updatedPeriod"
          @event-was-resized="reactToEvent"
          @edit-event="editEvent"
          @delete-event="deleteEvent"
          @day-was-clicked="reactToEvent"
          @event-was-dragged="handleEventWasDragged"
          @interval-was-clicked="handleIntervalWasClicked"
        >
        </Qalendar> -->
        <Qalendar
          :selected-date="new Date()"
          :events="events"
          :config="config"          
          @edit-event="editEvent"
          @delete-event="deleteEvent"
          @day-was-clicked="reactToEvent"
        >
        </Qalendar>        
    </div>
</template>

<script>
export default {
  data(){
    return {
      isFormShow: false
    }
  },
  methods : {
    editEvent(id) {
      console.log("EDIT EVENT!")
      console.log(id)
      this.isFormShow = true;
      console.log(this.isFormShow);
    },
    deleteEvent(id) {
      console.log("DELETE EVENT!")
      console.log(id)
    },
    reactToEvent(e) {
      console.log("REACT EVENT!")
      console.log(e)
    },
    async onSubmit(values) {
      try {
          let message;
          console.log(values);
          // if (user) {
          //     await usersStore.update(user.value.id, values)
          //     message = 'User updated';
          // } else {
          //     await usersStore.register(values);
          //     message = 'User added';
          // }
          // await router.push('/users');
          alertStore.success(message);
      } catch (error) {
          alertStore.error(error);
      }
    }
  }
}
</script>

<style>
    /** Please observe,
    that your path to the node_modules directory might be different */
    @import '../../node_modules/qalendar/dist/style.css';
</style>
